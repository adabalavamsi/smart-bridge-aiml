# Enchanted-Wings-Marvels-Of-Butterfly-Species
Enchanted Wings is a deep learning-based butterfly species classifier using MobileNetV2. It predicts 75 species from images via a Flask web app, showing sample images and species info. Designed for education, research, and conservation, it makes butterfly identification simple and engaging.
