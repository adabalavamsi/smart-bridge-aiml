This project uses the **Butterfly Image Classification** dataset from Kaggle, which contains images from 75 different species of butterflies.

**(https://www.kaggle.com/datasets/phucthaiv02/butterfly-image-classification)**

To use this dataset:
1. Create a free Kaggle account.
2. Download the dataset.
3. Extract the files and place them in the appropriate folder as per project instructions.
